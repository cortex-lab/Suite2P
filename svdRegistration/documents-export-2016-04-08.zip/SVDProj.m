function [U,cX] = SVDProj(A,B,isGPU)

if isGPU == 1
    A = gpuArray(A);
    B = gpuArray(B);
    U = gpuArray.zeros(size(A),'single');
else
    U = zeros(size(A),'single');
end

[nX nY nComps] = size(A);
for i = 1:nComps
    for j = 1:nComps
        U(:,:,i) = U(:,:,i) + B(:,:,j) * sum(sum(B(:,:,j) .* A(:,:,i)));
    end
end

	

% compare U and A
[cX,ix,cc] = regZ(U(:,:,1),A(:,:,1));


if isGPU == 1
	cX = gather(cX);
	U = gather(U);
end
